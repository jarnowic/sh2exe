#!/bin/sh
clear
echo -e "\n  +--------------------- +"
echo      "  | sh2exe sample script |"
echo -e   "  +----------------------+\n"

echo "sh2exe environment variables":
echo "S2E_BUSYBOX  "$S2E_BUSYBOX
echo "S2E_STARTDIR "$S2E_STARTDIR
echo "S2E_EXENAME  "$S2E_EXENAME
echo "HOME         "$HOME

echo -e "\nCommand line parameters:"
echo '$1: ' $1
echo '$2: ' $2
echo '$3: ' $3
echo '$4: ' $4

export PS1="[$S2E_BUSYBOX \W]\$ "

if [ "$S2E_BUSYBOX" = "Cygwin" ]; then
  echo -e "\nUnder Cygwin, make sure to convert the EOL of the script to UNIX format."
  echo "You can use dos2unix for this or Notepad++ (Edit / EOL Conversion / UNIX)"
  echo "The script will not work if the EOL is in CRLF format used by Windows."
fi

echo -e "\nStarting the shell...\n"
bash